# RePhrase — HS Hospital AI Rephraser

Select any text in WhatsApp or any app → floating bubble appears → tap a tone → text replaced instantly.

## Setup Instructions

### Step 1 — Upload to GitHub
1. Go to github.com → Sign in (or create free account)
2. Click **New Repository**
3. Name it: `rephrase-app`
4. Click **Create Repository**
5. Upload all these files (drag and drop the whole folder)

### Step 2 — Build the APK
1. Go to **Actions** tab in your repository
2. Click **Build APK**
3. Click **Run workflow** → **Run workflow**
4. Wait 3–5 minutes
5. Click the completed run → scroll down → **Download RePhrase-APK**

### Step 3 — Install on Android
1. Transfer APK to your phone
2. Open it → tap Install
3. If blocked: Settings → Install unknown apps → Allow

### Step 4 — Setup
1. Open **RePhrase** app
2. Paste your Claude API key → Save
3. Tap **Open Accessibility Settings**
4. Find **RePhrase** → Turn ON

### Step 5 — Use it!
1. Open WhatsApp
2. Select any text
3. Floating bubble appears with 10 tones
4. Tap any tone → text rephrased in 2 seconds!
